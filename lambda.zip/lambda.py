import json


def handler(event, context):
    number1 = 2
    number2 = 3
    return int(number1) + int(number2)

